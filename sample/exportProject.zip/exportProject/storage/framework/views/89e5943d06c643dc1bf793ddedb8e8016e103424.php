<!doctype html>
<html>
<?php echo $__env->make('layouts.default-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<head>
    <title>Stock - Admin Login</title>
    <!-- <link rel="stylesheet" type="text/css" href="css/style.css"> -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>

<body style="background-color:white;">
    <!-----------------new-login---------------------->
    <div class="login-bg">
        <div class="container login">
            <div class="row main" id="bg-white" style="">
                <div class="col-lg-6 logo">
                    <img src="<?php echo e(asset('theme/images/download.jfif')); ?>">
                    <div class="row">
                        <h1> <span id="green">Stock</span> <span id="blue">Replenishment </span></h1>
                    </div>
                </div>

                <div class="col-lg-6 form">
                    <div class="row">
                        <div class="col-md-12">
                            <h1>Login</h1>
                        </div>
                    </div>
                    <?php echo $__env->make('include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(url('login')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>



                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="email" class="form-control" placeholder="Username" name="email">
                                <div class="icon"> <img src="<?php echo e(asset('images/user1.png')); ?>"></div>
                                <?php if($errors->has('email')): ?>
                                <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="password" class="form-control" placeholder="Password" name="psw">
                                <div class="icon"> <img src="<?php echo e(asset('images/key.png')); ?>"></div>
                                <?php if($errors->has('psw')): ?>
                                <div class="error" style="color:red;"><?php echo e($errors->first('psw')); ?></div>


                                <?php endif; ?>


                                <!-- <p><a href="#">Forgot Password?</a></p> -->


                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-md-12">
                                <button class="btn btn-default" type="submit">LOGIN </button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!------------------------------------------------>



    <?php echo $__env->make('include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
    const inputs = document.querySelectorAll(".input");


    function addcl() {
        let parent = this.parentNode.parentNode;
        parent.classList.add("focus");
    }

    function remcl() {
        let parent = this.parentNode.parentNode;
        if (this.value == "") {
            parent.classList.remove("focus");
        }
    }


    inputs.forEach(input => {
        input.addEventListener("focus", addcl);
        input.addEventListener("blur", remcl);
    });




    $(".toggle-password").click(function() {

        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }
    });
    </script>

</body>





<!-- <body>
   <section class="Form my-4 mx-5">
       <div class="container">
           <div class="row no-gutters">
               <div class="col-lg-5">
                   <img src="<?php echo e(asset('theme/images/logo1.jpg')); ?>" class="img-fluid" alt="">
               </div>
               <div class="col-lg-7 text-center px-5 pt-5">
                   <h1 class="font-weight-bold py-3">Login</h1>
                   <h4>Sign into your account</h4>
                   <form action="<?php echo e(url('loginbmrc')); ?>" method="post">
                   <?php echo e(csrf_field()); ?>

                       <div class="form-row">
                           <div class="col-lg-7 ">
                               <input type="email" placeholder="Email" name="email" class="form-control my-3">
                               <?php if($errors->has('email')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
                           </div>

                       </div>
                       <div class="form-row">
                        <div class="col-lg-7 ">
                            <input  id="password-field" type="password" placeholder="Password" name="psw" class="form-control my-3">
                            <a href="javascript:void(0);"><span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span></a>
    <?php if($errors->has('psw')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('psw')); ?></div>
<?php endif; ?>
                        </div>

                    </div>
                    <?php echo $__env->make('include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="form-row">
                            <div class="col-lg-7">
                                <button type="submit"  class="btn1">Login</button>

                            </div>

                        </div>


                    </div>
                   </form>
               </div>
           </div>
       </div>
   </section>
 -->
<!-- <?php echo $__env->make('include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});




</script> -->
<!-- </body> -->











<!-- <div class="login-body">
<div class="text-center new-crd-hd">
		<img src="<?php echo e(asset('theme/images/bellevue-logo.jpeg')); ?>" alt="logo">
	</div>
	<div class="container col-md-8 login-container">

            <div class="row">

                <div class="col-md-12 login-form-1">
                    <h3>Login</h3>
					<p>Sign In to your account</p>
                    <form action="<?php echo e(url('loginbmrc')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

      <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="email" placeholder="Email" name="email"> -->
<!-- <?php if($errors->has('email')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?> -->
<!-- <?php if($errors->has('email')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
  </div>
  <div class="input-container">
    <i class="fa fa-key icon"></i>
    <input class="input-field" id="password-field" type="password" placeholder="Password" name="psw"> -->
<!--    <a href="javascript:void(0);"><i class="fa fa-eye" ></i></a>-->
<!-- <a href="javascript:void(0);"><span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span></a> -->
<!-- <?php if($errors->has('psw')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('psw')); ?></div>
<?php endif; ?> -->
<!-- <?php if($errors->has('psw')): ?>
        <div class="error" style="color:red;"><?php echo e($errors->first('psw')); ?></div>
<?php endif; ?>
  </div>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger" style="text-align:center;color: #ff0000;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i><em > <?php echo e(Session::get('login_error')); ?></em></div>
<?php endif; ?>
<?php if(Session::has('message')): ?>
<div class="alert alert-success" style="text-align:center;"><i class="fa fa-key"></i><em> <?php echo e(Session::get('message')); ?></em></div>
	<?php endif; ?>
   <div class="input-container">
   <button class="btn btn-default" type="submit" style="width:100%;">Login</button> -->
<!--<div class="col-md-8 frgt" style="float:right;"><a href="#"> Forgot Password?</a></div>-->

<!-- </div>
                    </form>
                </div>

            </div>
        </div>
</div>
  <?php echo $__env->make('include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});




</script>
</body>
</html> -->
<?php /**PATH /Users/user/Desktop/eit/exportProject/resources/views/home/login.blade.php ENDPATH**/ ?>