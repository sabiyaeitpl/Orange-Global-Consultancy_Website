<?php $__env->startSection('title'); ?>
 Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
	<?php echo $__env->make('errors.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('errors.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->make('errors.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>)

 <!-- Content -->
        <div class="content">
                <div class="card">
        <!-- /.row -->
	<div class="card-header" style="color:red;">
404 Page not found </div>
        <div class="card-body" style="margin-top: 20px;"><p align="center">
        	<!-- <a class="btn btn-primary" href="<?php echo e((url()->previous()!='')? url()->previous(): route('dashboard')); ?>">Back</a> -->
            <a class="btn btn-danger btn-sm" href="<?php echo e(url('/')); ?>">Back to Login</a>
        </p>
        </div>
 </div>
 
		</div>
        <!-- /.content -->
        <div class="clearfix"></div>
       


<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/Desktop/eit/exportProject/resources/views/errors/404.blade.php ENDPATH**/ ?>