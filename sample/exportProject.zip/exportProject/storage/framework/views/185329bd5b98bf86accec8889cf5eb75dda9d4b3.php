<!doctype html>
<html class="no-js" lang=""> 
 <?php echo $__env->make('include.head-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/Desktop/eit/exportProject/resources/views/layouts/default-login.blade.php ENDPATH**/ ?>