
<style>
.navbar .navbar-nav li.menu-item-has-children .sub-menu{padding-left:0;}
</style>

<?php if(Session('admin')->user_type=='user'): ?>
<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">

        <?php $menus = array();
            foreach ($Roledata as $roleaccess) {
                $menus[] = $roleaccess->menu;

            }
            $menuslist = array_unique($menus);
        ?>

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                </ul>
            </div>
        </nav>
    </aside>
 <?php else: ?>
 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="<?php echo e(url('dashboard')); ?>"><img src="<?php echo e(asset('images/dashboard-icon.png')); ?>" alt="" />Dashboard </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?php echo e(asset('images/financial-profit.png')); ?>" alt="" /> Export</a>
                        <ul class="sub-menu children dropdown-menu">
                            
                            <li><a href="<?php echo e(url('export/export-master')); ?>"><img src="<?php echo e(asset('images/lv-rule.png')); ?>" alt="" /> Export Master</a></li>
                            <li><a href="<?php echo e(url('export/good-master')); ?>"><img src="<?php echo e(asset('images/lv-rule.png')); ?>" alt="" /> Goods Master</a></li>
                            <li><a href="<?php echo e(url('export/create-pdf')); ?>"><img src="<?php echo e(asset('images/lv-rule.png')); ?>" alt="" /> Exporter Pass</a></li>
                            
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
</aside>

<?php endif; ?>
<?php /**PATH /Users/user/Desktop/eit/exportProject/resources/views/export/partials/sidebar.blade.php ENDPATH**/ ?>