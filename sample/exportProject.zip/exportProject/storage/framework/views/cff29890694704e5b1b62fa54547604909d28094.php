
  <?php if(Session::has('message')): ?>	
        <div class="alert alert-success alert-dismissable __web-inspector-hide-shortcut__">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <?php echo e(Session::get('message')); ?>

        </div>
<?php endif; ?>

 <?php if(Session::has('error')): ?>		
        <div class="alert alert-danger alert-dismissable">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <?php echo e(Session::get('error')); ?>

        </div>	
<?php endif; ?>


<div style="color: red; font-size: 16px; display: none;" id="draftmsg">Draft saved...!</div><?php /**PATH /Users/user/Desktop/eit/exportProject/resources/views/include/messages.blade.php ENDPATH**/ ?>