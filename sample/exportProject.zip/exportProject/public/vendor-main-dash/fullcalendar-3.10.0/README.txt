From full calendar

To avoid size and conflicts, I removed:
 lib/jquery*
 demos/


