<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Cast extends Model
{
    public $timestamps= false;
}
