<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Sub_cast extends Model
{
    public $timestamps= false;
    protected $primarykey='id';
}
