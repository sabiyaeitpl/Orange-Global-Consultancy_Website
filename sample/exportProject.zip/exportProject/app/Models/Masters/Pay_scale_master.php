<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Pay_scale_master extends Model
{

}
