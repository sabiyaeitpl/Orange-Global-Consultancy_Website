<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Rate_details extends Model
{
    public $timestamps= false;
}
