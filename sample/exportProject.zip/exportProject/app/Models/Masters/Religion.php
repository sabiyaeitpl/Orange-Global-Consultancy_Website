<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Religion extends Model
{
    public $timestamps= false;

}
