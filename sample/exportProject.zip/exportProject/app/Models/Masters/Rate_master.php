<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Rate_master extends Model
{

}
