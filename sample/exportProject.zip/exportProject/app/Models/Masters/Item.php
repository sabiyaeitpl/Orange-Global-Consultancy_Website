<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Item extends Model
{

}
