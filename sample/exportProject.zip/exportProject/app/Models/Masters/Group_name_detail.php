<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Group_name_detail extends Model
{
    protected $fillable = ['id', 'group_name', 'created_at', 'updated_at','status'];
}
