<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class State_master extends Model
{

}
