<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Depreciation_rate extends Model
{
    public $timestamps= false;
}
