<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Cooperative_master extends Model
{

    protected $fillable = ['id', 'cooperative_name', 'created_at', 'updated_at'];
}
