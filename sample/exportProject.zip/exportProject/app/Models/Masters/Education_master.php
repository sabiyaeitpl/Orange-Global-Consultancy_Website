<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Education_master extends Model
{
    protected $fillable = ['id', 'education', 'created_at', 'updated_at'];
}
