<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Bank_master extends Model
{
    public $timestamps= false;
}
