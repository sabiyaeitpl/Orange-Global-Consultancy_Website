<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Assets_mapping extends Model
{
    public $timestamps= false;
}
