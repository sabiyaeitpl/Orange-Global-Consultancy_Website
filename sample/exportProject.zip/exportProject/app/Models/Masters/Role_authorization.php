<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Role_authorization extends Model
{
    public $timestamps= false;
}
