<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class District_master extends Model
{

}
