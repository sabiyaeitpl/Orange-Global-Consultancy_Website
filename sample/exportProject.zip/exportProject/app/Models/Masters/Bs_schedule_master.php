<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Bs_schedule_master extends Model
{
    
    
}
