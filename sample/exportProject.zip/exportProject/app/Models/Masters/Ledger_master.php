<?php

namespace App\Models\Masters;

use Illuminate\Database\Eloquent\Model;

class Ledger_master extends Model
{
    
}
