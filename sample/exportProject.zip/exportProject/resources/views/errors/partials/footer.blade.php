<!-- Footer -->
<footer class="site-footer">
            <div class="footer-inner">
                <div class="row">
                    <div class="col-sm-6 text-center">
                        <p>Copyright &copy; <?=date('Y');?> Bellevue </p>
                    </div>
                    <div class="col-sm-6 text-right" style="padding-top:1.5%;">
                        Designed by <a href="http://eitpl.in/" target="_blank">E.I.T</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- /.site-footer -->