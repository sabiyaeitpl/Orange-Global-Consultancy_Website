<!doctype html>
<html class="no-js" lang=""> 
 @include('include.head')